#include <stdio.h>
#include "config.h"

int main ()
{
    printf ("This is %s %s\n", PACKAGE_NAME, "1.0");
    printf ("Hello, aututools!\n");

    return 0;
}
