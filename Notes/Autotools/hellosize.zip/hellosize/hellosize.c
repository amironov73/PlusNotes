#include <stdio.h>
#include "config.h"

int main ()
{
    printf ("Size of size_t is %d\n", SIZEOF_SIZE_T);

    return 0;
}
