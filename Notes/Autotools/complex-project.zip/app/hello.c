#include <stdio.h>
#include "something.h"

int main()
{
    int arg1 = 123, arg2 = 456;
    int result = some_function (arg1, arg2);

    printf ("Result is %d\n", result);

    return 0;
}