#ifndef SOMETHING_H
#define SOMETHING_H

extern int some_function (int arg1, int arg2);

#endif

