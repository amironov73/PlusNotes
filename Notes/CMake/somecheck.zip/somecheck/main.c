#include <stdio.h>
#include "config.h"

int main()
{

#ifdef HAVE_MALLOC_H
    printf ("Have <malloc.h>");
#endif

#ifdef HAVE_NOSUCHFILE_H
    printf ("Have <nosuchfile.h>");
#endif

    return 0;
}
